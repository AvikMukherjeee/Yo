package com.example.shippingbill.model;

public class ShippingDetails {

    private String shipperName;
    private String shipperAddress;
    private String shipperZip;
    private String receiverName;
    private String receiverAddress;
    private String receiverZip;
    private String productType;
    private double productWeight;
    private double productPrice;
    private String invoiceNumber;
    private String invoiceDate;

    // Getter and Setter for 'Shipper Name'
    public String getShipperName() {
        return shipperName;
    }

    public void setShipperName(String shipperName) {
        this.shipperName = shipperName;
    }

    // Getter and Setter for 'Shipper Address'
    public String getShipperAddress() {
        return shipperAddress;
    }

    public void setShipperAddress(String shipperAddress) {
        this.shipperAddress = shipperAddress;
    }

    // Getter and Setter for 'Shipper Zip'
    public String getShipperZip() {
        return shipperZip;
    }

    public void setShipperZip(String shipperZip) {
        this.shipperZip = shipperZip;
    }

    // Getter and Setter for 'Receiver Name'
    public String getReceiverName() {
        return receiverName;
    }

    public void setReceiverName(String receiverName) {
        this.receiverName = receiverName;
    }

    // Getter and Setter for 'Receiver Address'
    public String getReceiverAddress() {
        return receiverAddress;
    }

    public void setReceiverAddress(String receiverAddress) {
        this.receiverAddress = receiverAddress;
    }

    // Getter and Setter for 'Receiver Zip'
    public String getReceiverZip() {
        return receiverZip;
    }

    public void setReceiverZip(String receiverZip) {
        this.receiverZip = receiverZip;
    }

    // Getter and Setter for 'Product Type'
    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    // Getter and Setter for 'Product Weight'
    public double getProductWeight() {
        return productWeight;
    }

    public void setProductWeight(double productWeight) {
        this.productWeight = productWeight;
    }

    // Getter and Setter for 'Product Price'
    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    // Getter and Setter for 'Invoice Number'
    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    // Getter and Setter for 'Invoice Date'
    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }
}
