
// package com.example.shippingbill.service;

// import java.awt.image.BufferedImage;
// import java.io.FileOutputStream;
// import java.io.IOException;
// import java.util.List;

// import org.apache.poi.ss.usermodel.Row;
// import org.apache.poi.ss.usermodel.Sheet;
// import org.apache.poi.ss.usermodel.Workbook;
// import org.apache.poi.xssf.usermodel.XSSFWorkbook;
// import org.krysalis.barcode4j.impl.code128.Code128Bean;
// import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
// import org.springframework.stereotype.Service;

// import com.example.shippingbill.model.ShippingDetails;
// import com.itextpdf.text.Document;
// import com.itextpdf.text.DocumentException;
// import com.itextpdf.text.Element;
// import com.itextpdf.text.Image;
// import com.itextpdf.text.PageSize;
// import com.itextpdf.text.Paragraph;
// import com.itextpdf.text.Phrase;
// import com.itextpdf.text.pdf.ColumnText;
// import com.itextpdf.text.pdf.PdfWriter;

// import jakarta.servlet.http.HttpServletResponse;

// @Service
// public class ShippingBillService {

//     private int alignment;
//     private float fontSize;

//     // Save shipping details to Excel file
//     public void saveToExcel(List<ShippingDetails> shippingDetails, String excelFilePath) throws IOException {
//         @SuppressWarnings("resource")
//         Workbook workbook = new XSSFWorkbook();
//         Sheet sheet = workbook.createSheet("ShippingDetails");
//         int rowCount = 0;

//         // Add headers
//         Row headerRow = sheet.createRow(rowCount++);
//         headerRow.createCell(0).setCellValue("Shipper Name");
//         headerRow.createCell(1).setCellValue("Shipper Address");
//         headerRow.createCell(2).setCellValue("Shipper Zip");
//         headerRow.createCell(3).setCellValue("Receiver Name");
//         headerRow.createCell(4).setCellValue("Receiver Address");
//         headerRow.createCell(5).setCellValue("Receiver Zip");
//         headerRow.createCell(6).setCellValue("Product Type");
//         headerRow.createCell(7).setCellValue("Product Weight");
//         headerRow.createCell(8).setCellValue("Product Price");
//         headerRow.createCell(9).setCellValue("Invoice Number");
//         headerRow.createCell(10).setCellValue("Invoice Date");

//         // Add shipping details to Excel
//         for (ShippingDetails detail : shippingDetails) {
//             Row row = sheet.createRow(rowCount++);
//             row.createCell(0).setCellValue(detail.getShipperName());
//             row.createCell(1).setCellValue(detail.getShipperAddress());
//             row.createCell(2).setCellValue(detail.getShipperZip());
//             row.createCell(3).setCellValue(detail.getReceiverName());
//             row.createCell(4).setCellValue(detail.getReceiverAddress());
//             row.createCell(5).setCellValue(detail.getReceiverZip());
//             row.createCell(6).setCellValue(detail.getProductType());
//             row.createCell(7).setCellValue(detail.getProductWeight());
//             row.createCell(8).setCellValue(detail.getProductPrice());
//             row.createCell(9).setCellValue(detail.getInvoiceNumber());
//             row.createCell(10).setCellValue(detail.getInvoiceDate());
//         }

//         // Write the Excel file
//         try (FileOutputStream fileOut = new FileOutputStream(excelFilePath)) {
//             workbook.write(fileOut);
//         }
//     }

//     // Generate PDF with barcode and shipping details
//     public void generatePdf(List<ShippingDetails> shippingDetails, HttpServletResponse response) throws DocumentException, IOException {
//         response.setContentType("application/pdf");
//         response.setHeader("Content-Disposition", "attachment; filename=shippingbill.pdf");

//         Document document = new Document(PageSize.A4);
//         PdfWriter writer = PdfWriter.getInstance(document, response.getOutputStream());
//         document.open();

//         // Iterate over shipping details and generate PDF for each entry
//         for (ShippingDetails detail : shippingDetails) {
//             // Add Shipping Information Section
//             document.add(createParagraph("Shipping Bill")); // Title
//             document.add(createParagraph("Invoice Number: " + detail.getInvoiceNumber()));
//             document.add(createParagraph("Invoice Date: " + detail.getInvoiceDate()));
//             document.add(createParagraph("\n"));

//             // Shipper Information
//             document.add(createParagraph("Shipper Information:"));
//             document.add(createParagraph("Name: " + detail.getShipperName()));
//             document.add(createParagraph("Address: " + detail.getShipperAddress()));
//             document.add(createParagraph("Zip Code: " + detail.getShipperZip()));
//             document.add(createParagraph("\n"));

//             // Receiver Information
//             document.add(createParagraph("Receiver Information:"));
//             document.add(createParagraph("Name: " + detail.getReceiverName()));
//             document.add(createParagraph("Address: " + detail.getReceiverAddress()));
//             document.add(createParagraph("Zip Code: " + detail.getReceiverZip()));
//             document.add(createParagraph("\n"));

//             // Product Information
//             document.add(createParagraph("Product Information:"));
//             document.add(createParagraph("Type: " + detail.getProductType()));
//             document.add(createParagraph("Weight: " + detail.getProductWeight()));
//             document.add(createParagraph("Price: " + detail.getProductPrice()));
//             document.add(createParagraph("\n"));

//             // Generate Barcode using Barcode4J
//             Code128Bean barcode = new Code128Bean();
//             barcode.setHeight(15f);  // Set barcode height
//             barcode.setModuleWidth(0.2f);  // Set module width

//             // Create a bitmap canvas to draw the barcode
//             BitmapCanvasProvider canvas = new BitmapCanvasProvider(160, BufferedImage.TYPE_BYTE_BINARY, false, 0);
//             barcode.generateBarcode(canvas, detail.getInvoiceNumber());  // Using Invoice Number as barcode
//             canvas.finish();

//             // Create barcode image in the PDF
//             BufferedImage barcodeImage = canvas.getBufferedImage();
//             Image barcodePdfImage = Image.getInstance(barcodeImage, null);
//             barcodePdfImage.setAlignment(Element.ALIGN_CENTER);
//             document.add(barcodePdfImage);

//             // Add Page Number (at bottom-right)
//             Phrase pageNum = new Phrase("Page " + writer.getPageNumber(), new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10));
//             ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT, pageNum, 570, 30, 0);

//             // Add space before next page
//             document.newPage();
//         }

//         // Close the document after generating all pages
//         document.close();
//     }

//     // Helper method to create paragraphs with specified font size and alignment
//     private Paragraph createParagraph(String text) {
//         com.itextpdf.text.Font font = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, fontSize);
//         Paragraph paragraph = new Paragraph(text, font);
//         paragraph.setAlignment(alignment);
//         return paragraph;
//     }
// }

package com.example.shippingbill.service;

import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;
import org.springframework.stereotype.Service;

import com.example.shippingbill.model.ShippingDetails;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfWriter;

import jakarta.servlet.http.HttpServletResponse;

@Service
public class ShippingBillService {

    private int alignment;
    private float fontSize;

    // Save shipping details to Excel file
    public void saveToExcel(List<ShippingDetails> shippingDetails, String excelFilePath) throws IOException {
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("ShippingDetails");
        int rowCount = 0;

        // Add headers
        Row headerRow = sheet.createRow(rowCount++);
        headerRow.createCell(0).setCellValue("Shipper Name");
        headerRow.createCell(1).setCellValue("Shipper Address");
        headerRow.createCell(2).setCellValue("Shipper Zip");
        headerRow.createCell(3).setCellValue("Receiver Name");
        headerRow.createCell(4).setCellValue("Receiver Address");
        headerRow.createCell(5).setCellValue("Receiver Zip");
        headerRow.createCell(6).setCellValue("Product Type");
        headerRow.createCell(7).setCellValue("Product Weight");
        headerRow.createCell(8).setCellValue("Product Price");
        headerRow.createCell(9).setCellValue("Invoice Number");
        headerRow.createCell(10).setCellValue("Invoice Date");

        // Add shipping details to Excel
        for (ShippingDetails detail : shippingDetails) {
            Row row = sheet.createRow(rowCount++);
            row.createCell(0).setCellValue(detail.getShipperName());
            row.createCell(1).setCellValue(detail.getShipperAddress());
            row.createCell(2).setCellValue(detail.getShipperZip());
            row.createCell(3).setCellValue(detail.getReceiverName());
            row.createCell(4).setCellValue(detail.getReceiverAddress());
            row.createCell(5).setCellValue(detail.getReceiverZip());
            row.createCell(6).setCellValue(detail.getProductType());
            row.createCell(7).setCellValue(detail.getProductWeight());
            row.createCell(8).setCellValue(detail.getProductPrice());
            row.createCell(9).setCellValue(detail.getInvoiceNumber());
            row.createCell(10).setCellValue(detail.getInvoiceDate());
        }

        // Write the Excel file
        try (FileOutputStream fileOut = new FileOutputStream(excelFilePath)) {
            workbook.write(fileOut);
        }
    }

    // Generate PDF with barcode and shipping details
    public void generatePdf(List<ShippingDetails> shippingDetails, HttpServletResponse response) throws DocumentException, IOException, Exception {
        // Ensure the response content type and file name are set
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=shippingbill.pdf");

        // Create a new document instance
        Document document = new Document(PageSize.A4);
        PdfWriter writer = PdfWriter.getInstance(document, response.getOutputStream());

        try {
            // Open the document to write content
            document.open();

            for (ShippingDetails detail : shippingDetails) {
                // Add Shipping Information Section
                document.add(createParagraph("Shipping Bill"));
                document.add(createParagraph("Invoice Number: " + detail.getInvoiceNumber()));
                document.add(createParagraph("Invoice Date: " + detail.getInvoiceDate()));
                document.add(createParagraph("\n"));

                // Shipper Information
                document.add(createParagraph("Shipper Information:"));
                document.add(createParagraph("Name: " + detail.getShipperName()));
                document.add(createParagraph("Address: " + detail.getShipperAddress()));
                document.add(createParagraph("Zip Code: " + detail.getShipperZip()));
                document.add(createParagraph("\n"));

                // Receiver Information
                document.add(createParagraph("Receiver Information:"));
                document.add(createParagraph("Name: " + detail.getReceiverName()));
                document.add(createParagraph("Address: " + detail.getReceiverAddress()));
                document.add(createParagraph("Zip Code: " + detail.getReceiverZip()));
                document.add(createParagraph("\n"));

                // Product Information
                document.add(createParagraph("Product Information:"));
                document.add(createParagraph("Type: " + detail.getProductType()));
                document.add(createParagraph("Weight: " + detail.getProductWeight()));
                document.add(createParagraph("Price: " + detail.getProductPrice()));
                document.add(createParagraph("\n"));

                // Generate Barcode using Barcode4J
                generateBarcode(detail.getInvoiceNumber(), document, writer);

                // Add Page Number (at bottom-right)
                Phrase pageNum = new Phrase("Page " + writer.getPageNumber(), new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, 10));
                ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT, pageNum, 570, 30, 0);

                // Add space before next page
                document.newPage();
            }

        } catch (DocumentException | IOException e) {
            System.out.println("Error generating PDF: " + e.getMessage());
            e.printStackTrace();
            throw new IOException("Failed to generate the PDF document", e);
        } finally {
            document.close();
        }
    }

    // Helper method to create paragraphs with specified font size and alignment
    private Paragraph createParagraph(String text) {
        com.itextpdf.text.Font font = new com.itextpdf.text.Font(com.itextpdf.text.Font.FontFamily.HELVETICA, fontSize);
        Paragraph paragraph = new Paragraph(text, font);
        paragraph.setAlignment(alignment);
        return paragraph;
    }

    // Helper method to generate barcode for invoice number
    private void generateBarcode(String invoiceNumber, Document document, PdfWriter writer) throws Exception {
        Code128Bean barcode = new Code128Bean();
        barcode.setHeight(15f);
        barcode.setModuleWidth(0.2f);

        // Create a bitmap canvas to draw the barcode
        BitmapCanvasProvider canvas = new BitmapCanvasProvider(160, BufferedImage.TYPE_BYTE_BINARY, false, 0);
        barcode.generateBarcode(canvas, invoiceNumber);  // Using Invoice Number as barcode
        canvas.finish();

        // Create barcode image in the PDF
        BufferedImage barcodeImage = canvas.getBufferedImage();
        Image barcodePdfImage = Image.getInstance(barcodeImage, null);
        barcodePdfImage.setAlignment(Element.ALIGN_CENTER);
        document.add(barcodePdfImage);
    }
}
