// package com.example.shippingbill.controller;

// import java.io.IOException;
// import java.util.ArrayList;
// import java.util.List;

// import org.springframework.beans.factory.annotation.Value;
// import org.springframework.stereotype.Controller;
// import org.springframework.ui.Model;
// import org.springframework.web.bind.annotation.GetMapping;
// import org.springframework.web.bind.annotation.ModelAttribute;
// import org.springframework.web.bind.annotation.PostMapping;

// import com.example.shippingbill.model.ShippingDetails;
// import com.example.shippingbill.service.ShippingBillService;

// import jakarta.servlet.http.HttpServletResponse;

// @Controller
// public class ShippingController {

//     private final ShippingBillService shippingService;
//     private final List<ShippingDetails> shippingDetails = new ArrayList<>();

//     @Value("${shipping.excel.path}")
//     private String excelFilePath;

//     public ShippingController(ShippingBillService shippingService) {
//         this.shippingService = shippingService;
//     }

//     @GetMapping("/")
//     public String showForm(Model model) {
//         model.addAttribute("shippingDetail", new ShippingDetails());
//         return "shipping-form";
//     }

//     @PostMapping("/addItem")
//     public String addItem(@ModelAttribute ShippingDetails shippingDetail, Model model) throws IOException {
//         shippingDetails.add(shippingDetail);
//         shippingService.saveToExcel(shippingDetails, excelFilePath);
//         model.addAttribute("shippingDetail", new ShippingDetails());
//         return "shipping-form";
//     }

//     @GetMapping("/generatePdf")  // Make sure this mapping is correct
//     public void generatePdf(HttpServletResponse response) throws Exception {
//         shippingService.generatePdf(shippingDetails, response);
//     }
// }
package com.example.shippingbill.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.shippingbill.model.ShippingDetails;
import com.example.shippingbill.service.ShippingBillService;

import jakarta.servlet.http.HttpServletResponse;

@Controller
public class ShippingController {

    private final ShippingBillService shippingService;

    private final List<ShippingDetails> shippingDetails = new ArrayList<>();

    @Value("${shipping.excel.path}")
    private String excelFilePath;

    public ShippingController(ShippingBillService shippingService) {
        this.shippingService = shippingService;
    }

    @GetMapping("/")
    public String showForm(Model model) {
        model.addAttribute("shippingDetail", new ShippingDetails());
        return "shipping-form";
    }

    @PostMapping("/addItem")
    public String addItem(@ModelAttribute ShippingDetails shippingDetail, Model model) throws IOException {
        shippingDetails.add(shippingDetail);

        // Save shipping details to Excel
        shippingService.saveToExcel(shippingDetails, excelFilePath);

        model.addAttribute("shippingDetail", new ShippingDetails());
        return "shipping-form";
    }

    @GetMapping("/generatePdfmain")
    public void generatePdf(HttpServletResponse response) throws Exception {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=shippingbill.pdf");

        try {
            shippingService.generatePdf(shippingDetails, response);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("An error occurred while generating the PDF: " + e.getMessage());
        }
    }
}
